import objectbase

class SunLight(objectbase.ObjectBase):
    pass