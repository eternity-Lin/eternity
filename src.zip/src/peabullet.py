import objectbase

class PeaBullet(objectbase.ObjectBase):   
    pass





