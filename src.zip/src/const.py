GAME_SIZE = (1280,600)
LEFT_TOP = (200,65)
GRID_SIZE = (76,96)
GRID_COUNT = (9,5)
PATH_BACK = 'D:\E\Python3.11\python\pvz\src\pic\other\\back.png'

SUNFLOWER_ID = 3
PEASHOOTER_ID = 4

ZOMBIE_BORN_X = 14
ZOMBIE_BORN_CD = 20