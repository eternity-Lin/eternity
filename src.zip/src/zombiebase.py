import objectbase

class ZombieBase(objectbase.ObjectBase):
    pass